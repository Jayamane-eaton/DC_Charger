



float xyinterp_f32(float y_1, float y_0, float x_1, float x_0, float x);
