



double xyinterp_f64(double y_1, double y_0, double x_1, double x_0, double x);
